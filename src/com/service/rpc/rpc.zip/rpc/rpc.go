package rpc

import (
	"com/share/glob"
	"github.com/garyburd/redigo/redis"
	"ops/cf/app"
)

var (
	RPC_CONTEXT app.Context
	RPC_REDIS   *redis.Pool
)

func init() {
	var gap *glob.AppContext = glob.CurrContext()
	RPC_CONTEXT = gap
	RPC_REDIS = gap.Redis
}

/*
	var rpcServ *rpc.Server
	if(jsonRpc){
		rpcServ = rpc.NewServer()
		var point *mlrpc.PointRpc = new(mlrpc.PointRpc)
		rpcServ.RegisterName("point",point)
	}

	go rpcServ.ServeCodec(jsonrpc.NewServerCodec(conn))

*/
