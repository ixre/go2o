package server

// 订单属于Partner提交，原则上Member在Partner的平台上订单，
// 由Partner负责提交
