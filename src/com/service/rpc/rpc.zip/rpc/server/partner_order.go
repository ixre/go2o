package server

import (
	"com/ording/dao"
	"com/service/rpc"
	"strconv"
)

func (this *Partner) SubmitOrder(a *rpc.Args, r *rpc.Result) (err error) {
	var partnerId int
	if partnerId, err, _ = VerifyPartner(a); err != nil {
		return err
	}

	memberId, _ := strconv.Atoi((*a)["member_id"])
	shopId, _ := strconv.Atoi((*a)["shop_id"])
	paymethod, _ := strconv.Atoi((*a)["pay_method"])
	items := (*a)["items"]
	note := (*a)["note"]

	orderNo, err := dao.Order().CreateOrder(
		partnerId, memberId, shopId,
		paymethod, items, note)
	if err != nil {
		return err
	}
	r.Result = true
	r.Data = orderNo
	return nil
}
