package server

import (
	"com/ording"
	"com/ording/dao"
	"com/ording/entity"
	"com/service/rpc"
	"errors"
	"fmt"
	"github.com/garyburd/redigo/redis"
	"log"
	"ops/cf/crypto"
	"strconv"
	"strings"
	"time"
)

type Member struct{}

//登录验证
func (this *Member) Login(a rpc.Args, r *rpc.Result) error {
	usr, _ := a["usr"]
	pwd, _ := a["pwd"]

	b, m := dao.Member().Login(usr, pwd)

	r.Result = b
	if !b {
		r.Message = "用户密码不正确"
	} else {
		md5 := strings.ToLower(crypto.Md5([]byte(time.Now().String())))
		rds := rpc.RPC_REDIS.Get()
		rds.Do("SETEX", fmt.Sprintf("member$%d_session_key", m.Id), 3600*300, md5)
		r.Data = fmt.Sprintf("%d$%s", m.Id, md5)

		if rpc.RPC_CONTEXT.Debug() {
			log.Printf("[Member][Login]%d -- %s", m.Id, md5)
		}

		rds.Close()
	}
	return nil
}

func (this *Member) Verfy(a rpc.Args, r *rpc.Result) (err error) {
	var memberId int
	memberId, err = strconv.Atoi(a["member_id"])
	rpc.LogErr(err)
	if err != nil {
		return err
	}
	postToken := a["token"]
	if postToken == "" {
		return errors.New("missing member token!")
	}
	rds := rpc.RPC_REDIS.Get()
	defer rds.Close()

	sessKey := fmt.Sprintf("member$%d_session_key", memberId)
	token, err := redis.String(rds.Do("GET", sessKey))
	rpc.LogErr(err)
	if err != nil {
		return err
	}

	if token != postToken {
		r.Result = false
		return errors.New("会话超时，请重新登录！")
	} else {
		r.Result = true
		rds.Do("SETEX", sessKey, 3600*300, token) //更新回话并延长时间
	}
	return nil
}

func (this *Member) GetMember(a *rpc.Args, r *rpc.Result) (err error) {
	var memberId int
	if memberId, err = Verify(a); err != nil {
		rpc.LogErr(err)
		return err
	}
	e := dao.Member().GetMemberById(memberId)
	if e != nil {
		r.Data = rpc.MashalString(e)
		r.Result = true
	}
	return nil
}

func (this *Member) GetMemberRelation(a *rpc.Args, r *rpc.Result) (err error) {
	var memberId int
	if memberId, err = Verify(a); err != nil {
		rpc.LogErr(err)
		return err
	}
	e := dao.MemberRelation().GetMemberAccount(memberId)
	if e != nil {
		r.Data = rpc.MashalString(e)
		r.Result = true
	}
	return nil
}

func (this *Member) GetBankInfo(a *rpc.Args, r *rpc.Result) (err error) {
	var memberId int
	if memberId, err = Verify(a); err != nil {
		rpc.LogErr(err)
		return err
	}
	e := dao.MemberRelation().GetBankInfo(memberId)
	if e != nil {
		r.Data = rpc.MashalString(e)
		r.Result = true
	}
	return nil
}

func (this *Member) Register(a *rpc.Args, r *rpc.Result) (err error) {
	m := entity.Member{}
	if err = rpc.UnmarshalString((*a)["json"], &m); err != nil {
		return err
	}
	var cardId string
	var ptid int
	var tgid int

	cardId = (*a)["card_id"]
	ptid, _ = strconv.Atoi((*a)["partner_id"])
	tgid, _ = strconv.Atoi((*a)["tg_id"])

	//如果卡片ID为空时，自动生成
	if cardId == "" {
		cardId = time.Now().Format("200601021504")
	}

	m.Pwd = ording.EncodeMemberPwd(m.Usr, m.Pwd)
	err = dao.Member().Create(&m, ptid, tgid, cardId)
	rpc.LogErr(err)
	r.Result = err == nil
	return err
}

func (this *Member) SaveMember(a *rpc.Args, r *rpc.Result) (err error) {
	if _, err = Verify(a); err != nil {
		rpc.LogErr(err)
		return err
	}

	e := entity.Member{}
	if err = rpc.UnmarshalString((*a)["json"], &e); err != nil {
		return err
	}
	mm := dao.Member().GetMemberById(e.Id)

	//更新
	mm.Name = e.Name
	mm.Address = e.Address
	mm.Birthday = e.Birthday
	mm.Email = e.Email
	mm.Phone = e.Phone
	mm.Sex = e.Sex
	mm.Qq = e.Qq

	err = dao.Member().Save(mm)
	return err
}
