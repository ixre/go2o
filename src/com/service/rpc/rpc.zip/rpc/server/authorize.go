package server

import (
	"com/ording/dao"
	"com/ording/entity"
	"com/service/rpc"
	"errors"
	"fmt"
	"github.com/garyburd/redigo/redis"
	"log"
	"strconv"
)

//验证用户是否有权限
func Verify(a *rpc.Args) (memberId int, err error) {
	memberId, err = strconv.Atoi((*a)["member_id"])
	postToken := (*a)["token"]
	if postToken == "" {
		return memberId, errors.New("missing member token!")
	}
	rds := rpc.RPC_REDIS.Get()
	defer rds.Close()

	sessKey := fmt.Sprintf("member$%d_session_key", memberId)
	token, err := redis.String(rds.Do("GET", sessKey))
	if err != nil {
		return memberId, err
	}

	if token != postToken {
		if rpc.RPC_CONTEXT.Debug() {
			log.Println("[Member][Verify]", memberId, postToken, token)
		}
		return memberId, errors.New("会话超时，请重新登录！")
	} else {
		rds.Do("SETEX", sessKey, 3600*3, token) //更新回话并延长时间
	}
	return memberId, nil
}
func VerifyPartner(a *rpc.Args) (partnerId int, err error, p *entity.Partner) {
	partnerId, err = strconv.Atoi((*a)["partner_id"])
	postSecret := (*a)["secret"]
	if postSecret == "" {
		return partnerId, errors.New("missing token secret!"), nil
	}

	//	rds := rpc.RPC_REDIS.Get()
	//	defer rds.Close()
	//	sessKey := fmt.Sprintf("partner$%d_secret", partnerId)
	//	token, err := redis.String(rds.Do("GET", sessKey))
	//	if err != nil {
	//		return memberId, err
	//	}
	//
	//	if token != postToken {
	//		if rpc.RPC_CONTEXT.Debug() {
	//			log.Println("[Member][Verify]", memberId, postToken, token)
	//		}
	//		return memberId, errors.New("会话超时，请重新登录！")
	//	} else {
	//		rds.Do("SETEX", sessKey, 3600*3, token) //更新回话并延长时间
	//	}
	//	return memberId, nil

	p = dao.Partner().GetPartnerById(partnerId)
	if p == nil {
		return partnerId, errors.New("no such partner"), nil
	}

	if p.Secret != postSecret {
		return partnerId, errors.New("not authorized"), nil
	}

	return partnerId, nil, p
}
