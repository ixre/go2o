// 合作商户的接口
package server

import (
	"com/ording/dao"
	"com/service/rpc"
)

type Partner struct{}

func (this *Partner) GetPartner(a *rpc.Args, r *rpc.Result) (err error) {
	var partnerId int
	if partnerId, err, _ = VerifyPartner(a); err != nil {
		return err
	}
	e := dao.Partner().GetPartnerById(partnerId)
	r.Result = true
	r.Data = rpc.MashalString(e)
	return nil
}
