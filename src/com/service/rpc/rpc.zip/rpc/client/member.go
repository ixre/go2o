package client

import (
	"com/ording/entity"
	"com/service/rpc"
	"strconv"
)

type member struct {
	*dial
}

func (this *member) Login(usr, pwd string) (b bool, token string, err error) {
	cli, _err := this.dial.Dial()
	if _err != nil {
		return false, "", _err
	}

	var params rpc.Args = make(map[string]string, 2)
	var result rpc.Result
	params["usr"] = usr
	params["pwd"] = pwd
	err = cli.Call("Member.Login", &params, &result)
	rpc.LogErr(err)
	return result.Result, result.Data, err
}

func (this *member) Verfy(memberId int, token string) (b bool, err error) {
	cli, _err := this.dial.Dial()
	if _err != nil {
		return false, _err
	}

	var params rpc.Args = make(map[string]string, 2)
	var result rpc.Result
	params["member_id"] = strconv.Itoa(memberId)
	params["token"] = token
	err = cli.Call("Member.Verfy", &params, &result)
	rpc.LogErr(err)
	return result.Result, err
}

func (this *member) GetMember(memberId int, token string) (a *entity.Member, err error) {
	cli, _err := this.dial.Dial()
	if _err != nil {
		return nil, _err
	}

	var params rpc.Args = make(map[string]string, 2)
	var result rpc.Result
	params["member_id"] = strconv.Itoa(memberId)
	params["token"] = token
	err = cli.Call("Member.GetMember", &params, &result)
	rpc.LogErr(err)
	if result.Data != "" {
		a = &entity.Member{}
		rpc.UnmarshalString(result.Data, a)
	}
	return a, err
}

func (this *member) GetMemberRelation(memberId int, token string) (a *entity.MemberAccount, err error) {
	cli, _err := this.dial.Dial()
	if _err != nil {
		return nil, _err
	}

	var params rpc.Args = make(map[string]string, 2)
	var result rpc.Result
	params["member_id"] = strconv.Itoa(memberId)
	params["token"] = token
	err = cli.Call("Member.GetMemberRelation", &params, &result)
	rpc.LogErr(err)
	if result.Data != "" {
		a = &entity.MemberAccount{}
		rpc.UnmarshalString(result.Data, a)
	}
	return a, err
}

func (this *member) GetBankInfo(memberId int, token string) (a *entity.BankInfo, err error) {
	cli, _err := this.dial.Dial()
	if _err != nil {
		return nil, _err
	}

	var params rpc.Args = make(map[string]string, 2)
	var result rpc.Result
	params["member_id"] = strconv.Itoa(memberId)
	params["token"] = token
	err = cli.Call("Member.GetBankInfo", &params, &result)
	rpc.LogErr(err)
	if result.Data != "" {
		a = &entity.BankInfo{}
		rpc.UnmarshalString(result.Data, a)
	}
	return a, err
}

func (this *member) Register(m *entity.Member, partnerId, tgId int, cardId string) (b bool, err error) {
	cli, _err := this.dial.Dial()

	if _err != nil {
		return false, _err
	}
	var params rpc.Args = make(map[string]string, 4)
	var result rpc.Result
	params["partner_id"] = strconv.Itoa(partnerId)
	params["tg_id"] = strconv.Itoa(tgId)
	params["card_id"] = cardId
	params["json"] = rpc.MashalString(m)

	err = cli.Call("Member.Register", &params, &result)
	rpc.LogErr(err)
	return result.Result, err
}

func (this *member) SaveMember(m *entity.Member, token string) error {
	cli, _err := this.dial.Dial()
	if _err != nil {
		return _err
	}

	var params rpc.Args = make(map[string]string, 3)
	var result rpc.Result
	params["json"] = rpc.MashalString(m)
	params["member_id"] = strconv.Itoa(m.Id)
	params["token"] = token

	err := cli.Call("Member.SaveMember", &params, &result)
	rpc.LogErr(err)
	return err
}
