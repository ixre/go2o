package client

var (
	server   string
	_dial    *dial
	_member  *member
	_partner *partner
)

func SetServer(server string, jsonRpc bool, http bool) {
	server = server
	_dial = &dial{network: "tcp", server: server, isJsonRpc: jsonRpc, isHttp: http}
}

func Member() *member {
	if _member == nil {
		_member = &member{dial: _dial}
	}
	return _member
}

func Partner() *partner {
	if _partner == nil {
		_partner = &partner{dial: _dial}
	}
	return _partner
}

func Close() error {
	return _dial.Close()
}
