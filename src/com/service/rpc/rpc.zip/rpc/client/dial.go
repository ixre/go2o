package client

import (
	"net/rpc"
	"net/rpc/jsonrpc"
)

type dial struct {
	network   string
	server    string
	isJsonRpc bool
	isHttp    bool
	client    *rpc.Client
}

func (this *dial) Dial() (client *rpc.Client, err error) {
	if this.client == nil {
		if this.isJsonRpc {
			this.client, err = jsonrpc.Dial(this.network, this.server)
		} else {
			if this.isHttp {
				this.client, err = rpc.DialHTTP(this.network, this.server)
			} else {
				this.client, err = rpc.Dial(this.network, this.server)
			}
		}
	}
	return this.client, err
}

func (this *dial) Close() error {
	if this.client != nil {
		return this.client.Close()
	}
	return nil
}
