package rpc

//这个包已经过期，因为golang rpc不能与其他语言交互
//使用com/service/server包代替
