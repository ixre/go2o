package rpc

// [ test command ] :
// go test rpc_test.go result.go -v

import (
	"fmt"
	"net/rpc/jsonrpc"
	"testing"
)

func Test_rpc(t *testing.T) {
	client, err := jsonrpc.Dial("tcp", "127.0.0.1:1002")
	if err != nil {
		t.Error(err.Error())
	}
	var params Args = make(map[string]interface{}, 2)
	var result Result
	params["usr"] = "newmin"
	params["pwd"] = "123000"

	err = client.Call("Member.Login", &params, &result)

	if err != nil {
		t.Error(err.Error())
	} else {
		fmt.Println(result)
	}

}
