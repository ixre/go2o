package rpc

// json-rpc无法在客户端反序化为实体，
// 所以data需要返回字符串

//输出结果
type Result struct {
	Result  bool   `json:"result"`
	Code    int    `json:"code"`
	Data    string `json:"data"`
	Message string `json:"message"`
}

//参数
type Args map[string]string
