package rpc

import (
	_ "com/ording"
	"com/ording/entity"
	"com/service/rpc/client"
	"com/share/glob"
	"com/share/variable"
	"fmt"
	"log"
	"strconv"
	"strings"
	"testing"
	"time"
)

func Test_test(t *testing.T) {
	context := glob.NewContext()
	client.SetServer(":"+context.Config().Get(variable.SocketPort), !false, !true)

	//go testRegister()
	//fmt.Println(ording.NewSecret(666888))

	//go testPartner()
	//go testSubmitOrder()

	for {
		time.Sleep(2 * time.Second)
		go testMemberLogin()
	}
}
func testRegister() {
	m := entity.Member{
		Usr:      "test",
		Pwd:      "test",
		Name:     "测试员",
		Sex:      1,
		Avatar:   "",
		Birthday: "1988-11-09",
		Phone:    "18616999822",
		Address:  "",
		Qq:       "",
		Email:    "",
		RegIp:    "127.0.0.1",
	}
	b, err := client.Member().Register(&m, 666888, 0, "")
	if err != nil {
		fmt.Println(err.Error())

	} else {
		fmt.Println("注册成功")
	}
	b, _, _ = client.Member().Login(m.Usr, m.Pwd)
	if b {
		fmt.Println("登录成功")
	} else {
		fmt.Printf("登录失败：Usr:%s,Pwd:%s\n", m.Usr, m.Pwd)
	}
}

func testPartner() {
	p, err := client.Partner().GetPartner(666888, "d435a520e50e960b")
	if err != nil {
		log.Println("[Error]", err.Error())
	} else {
		log.Println(p)
	}
}

//用户中心

func testMemberLogin() {
	b, t, _ := client.Member().Login("newmin", "123000")
	if b {
		arr := strings.Split(t, "$")
		id, _ := strconv.Atoi(arr[0])
		token := arr[1]
		b, err := client.Member().Verfy(id, token)
		if b {
			fmt.Print("成功\n")
		} else {
			fmt.Println("[Error]", err.Error())
		}

		acc, err := client.Member().GetMemberRelation(id, token)
		if acc != nil {
			fmt.Print(*acc)
		}
	}

}

func testSubmitOrder() {
//	items := "2*1|3*2|4*1"
//	orderNo, err := client.Partner().SubmitOrder(666888, "d435a520e50e960b",
//		1, 0, 1, items, "")
//	if err != nil {
//		log.Println("[Error]", err.Error())
//	} else {
//		log.Println("[OrderNo]", orderNo)
//	}
}
