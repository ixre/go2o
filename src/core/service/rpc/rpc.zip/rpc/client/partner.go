package client

import (
	"com/ording/entity"
	"com/service/rpc"
	"strconv"
)

type partner struct {
	*dial
}

func (this *partner) GetPartner(partnerId int, secret string) (a *entity.Partner, err error) {
	cli, _err := this.dial.Dial()
	if _err != nil {
		return nil, _err
	}
	var params rpc.Args = make(map[string]string, 2)
	var result rpc.Result
	params["partner_id"] = strconv.Itoa(partnerId)
	params["secret"] = secret
	err = cli.Call("Partner.GetPartner", &params, &result)
	rpc.LogErr(err)
	if result.Data != "" {
		a = &entity.Partner{}
		rpc.UnmarshalString(result.Data, a)
	}
	return a, err
}

// 提交订单，并返回订单号
func (this *partner) SubmitOrder(partnerId int, secret string, memberId int,
	shopId int, paymethod int, items string, note string) (orderNo string, err error) {

	cli, _err := this.dial.Dial()
	if _err != nil {
		return "", _err
	}
	var params rpc.Args = make(map[string]string, 2)
	var result rpc.Result
	params["partner_id"] = strconv.Itoa(partnerId)
	params["secret"] = secret
	params["member_id"] = strconv.Itoa(memberId)
	params["shop_id"] = strconv.Itoa(shopId)
	params["pay_method"] = strconv.Itoa(paymethod)
	params["items"] = items
	params["note"] = note

	err = cli.Call("Partner.SubmitOrder", &params, &result)
	if !result.Result {
		rpc.LogErr(err)
		return "", err
	}

	return result.Data, err
}
