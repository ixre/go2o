package rpc

import (
	"encoding/json"
	"errors"
	"log"
)

func LogErr(err error) {
	if err != nil && RPC_CONTEXT.Debug() {
		log.Println("[Error]:", err)
	}
}

func MashalString(e interface{}) string {
	if e != nil {
		js, _ := json.Marshal(e)
		return string(js)
	}
	return ""
}

func UnmarshalString(s string, e interface{}) error {
	if e != nil {
		return json.Unmarshal([]byte(s), e)
	}
	return errors.New("entity is null.")
}
