# THRIFT 服务

## 编写IDL
   idl文件存放于： idl/service_idl.thrift
   
## 生成代码
   运行thrift-gen_test.go，文件中分别包含对应语言的生成方法
   
## 服务的实现
   服务的实现存放于目录rsi(Rpc service implement)下