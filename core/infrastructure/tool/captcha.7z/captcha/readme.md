# golang实现的验证码 golang captcha

原代码在freetype新版本中无法编译通过，修改后存放在这里。

库地址： http://github.com/afocus/captcha




